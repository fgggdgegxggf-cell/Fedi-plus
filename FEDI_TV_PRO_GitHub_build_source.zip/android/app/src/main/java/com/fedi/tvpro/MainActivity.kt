package com.fedi.tvpro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.PopupProperties
import java.util.Locale
import kotlinx.coroutines.launch

private val FediPurple = Color(0xFF7C3AED)
private val FediDeep = Color(0xFF0E0A18)
private val FediCard = Color(0xFF1D142B)
private val FediWhite = Color(0xFFFFFFFF)
private val FediMuted = Color(0xFFC9C1D6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FediTvProApp() }
    }
}

@Composable
private fun FediTvProApp() {
    val context = LocalContext.current
    val preferences = remember { context.getSharedPreferences("fedi_tv_pro_settings", android.content.Context.MODE_PRIVATE) }
    var language by remember { mutableStateOf(preferences.getString("language", "العربية") ?: "العربية") }
    var session by remember { mutableStateOf<XtreamSession?>(null) }
    var servers by remember { mutableStateOf(emptyList<FediServer>()) }
    var serversLoading by remember { mutableStateOf(true) }
    var serversError by remember { mutableStateOf(false) }
    var invalidServerCount by remember { mutableStateOf(0) }
    var selectedServer by remember { mutableStateOf<FediServer?>(null) }
    LaunchedEffect(Unit) {
        val result = ServerConfig.loadDetailed(context)
        val outcome = result.getOrNull()
        servers = outcome?.servers.orEmpty()
        invalidServerCount = outcome?.invalidEntries ?: 0
        selectedServer = servers.firstOrNull()
        serversError = result.isFailure || servers.isEmpty()
        serversLoading = false
    }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var activationCode by remember { mutableStateOf("") }
    var languageMenuOpen by remember { mutableStateOf(false) }
    var serverMenuOpen by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val isArabic = language == "العربية"
    val direction = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr

    if (session != null) {
        CompositionLocalProviderWithDirection(direction) {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = FediDeep) {
                    DashboardScreen(session = session!!, language = language, onLogout = { session = null })
                }
            }
        }
        return
    }

    CompositionLocalProviderWithDirection(direction) {
        MaterialTheme {
            Surface(modifier = Modifier.fillMaxSize(), color = FediDeep) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 28.dp, vertical = 22.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            text = "FEDI TV PRO",
                            color = FediWhite,
                            fontSize = 25.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.semantics { contentDescription = "FEDI TV PRO" },
                        )
                        LanguageMenu(
                            current = language,
                            open = languageMenuOpen,
                            onOpenChange = { languageMenuOpen = it },
                            onSelect = {
                                language = it
                                preferences.edit().putString("language", it).apply()
                            },
                        )
                    }

                    Spacer(modifier = Modifier.height(22.dp))
                    val loginTitle = when (language) {
                        "Français" -> "Connectez-vous à votre service TV"
                        "English" -> "Connect to your TV service"
                        else -> "سجّل الدخول إلى خدمة التلفزيون الخاصة بك"
                    }
                    Text(
                        text = loginTitle,
                        color = FediWhite,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.semantics { contentDescription = loginTitle },
                    )
                    Text(
                        text = when (language) {
                            "Français" -> "Choisissez un serveur, puis saisissez vos identifiants."
                            "English" -> "Choose a server, then enter your credentials."
                            else -> "اختر الخادم ثم أدخل بيانات الدخول الخاصة بك."
                        },
                        color = FediMuted,
                        fontSize = 15.sp,
                    )

                    if (serversLoading) Text("${when (language) { "Français" -> "Chargement des serveurs…"; "English" -> "Loading servers…"; else -> "جارٍ تحميل الخوادم…" }}", color = FediMuted)
                    if (serversError) Text("${when (language) { "Français" -> "Aucun serveur configuré."; "English" -> "No configured server available."; else -> "لا يوجد خادم مُعدّ متاح." }}", color = Color(0xFFFFB4AB), modifier = Modifier.semantics { contentDescription = fediText(language, "لا يوجد خادم متاح", "Aucun serveur disponible", "No server available") })
                    if (!serversLoading && invalidServerCount > 0) Text(
                        text = when (language) {
                            "Français" -> "$invalidServerCount configuration(s) de serveur ignorée(s) : adresse ou port invalide."
                            "English" -> "$invalidServerCount server configuration(s) ignored: invalid address or port."
                            else -> "تم تجاهل $invalidServerCount من إعدادات الخادم: العنوان أو المنفذ غير صالح."
                        },
                        color = Color(0xFFFFB4AB),
                        modifier = Modifier.semantics { contentDescription = fediText(language, "إعدادات خادم غير صالحة", "Configuration de serveur invalide", "Invalid server configuration") },
                    )
                    ServerMenu(
                        selected = selectedServer?.displayName ?: "",
                        open = serverMenuOpen,
                        onOpenChange = { serverMenuOpen = it },
                        servers = servers,
                        onSelect = { selectedServer = it },
                        label = when (language) {
                            "Français" -> "Serveur"
                            "English" -> "Server"
                            else -> "الخادم"
                        },
                    )

                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .semantics { contentDescription = fediText(language, "اسم المستخدم", "Nom d’utilisateur", "Username") },
                        label = { Text(fediText(language, "اسم المستخدم", "Nom d’utilisateur", "Username")) },
                        singleLine = true,
                    )
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .semantics { contentDescription = fediText(language, "كلمة المرور", "Mot de passe", "Password") },
                        label = { Text(fediText(language, "كلمة المرور", "Mot de passe", "Password")) },
                        singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    )
                    OutlinedTextField(
                        value = activationCode,
                        onValueChange = { activationCode = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .semantics { contentDescription = fediText(language, "رمز التفعيل", "Code d’activation", "Activation code") },
                        label = {
                            Text(
                                when (language) {
                                    "Français" -> "Code d'activation"
                                    "English" -> "Activation code"
                                    else -> "رمز التفعيل"
                                },
                            )
                        },
                        singleLine = true,
                    )

                    Button(
                        onClick = {
                            if (selectedServer == null) {
                                status = when (language) { "Français" -> "Aucun serveur disponible."; "English" -> "No server available."; else -> "لا يوجد خادم متاح." }
                            } else if (username.isBlank() || password.isBlank()) {
                                status = when (language) {
                                    "Français" -> "Saisissez le nom d'utilisateur et le mot de passe."
                                    "English" -> "Enter your username and password."
                                    else -> "أدخل اسم المستخدم وكلمة المرور."
                                }
                            } else if (activationCode.trim().length < 4) {
                                status = when (language) {
                                    "Français" -> "Saisissez un code d'activation valide."
                                    "English" -> "Enter a valid activation code."
                                    else -> "أدخل رمز تفعيل صالحًا."
                                }
                            } else if (!isLoading) {
                                scope.launch {
                                    isLoading = true
                                    status = when (language) {
                                        "Français" -> "Vérification en cours…"
                                        "English" -> "Checking your subscription…"
                                        else -> "جارٍ التحقق من الاشتراك…"
                                    }
                                    val result = selectedServer?.let { server ->
                                        XtreamClient.login(server.baseUrl, username, password)
                                    } ?: XtreamLoginResult(false, "NO_SERVER")
                                    status = if (result.success) {
                                        session = selectedServer?.let { server -> XtreamSession(server, username, password, result.expiryTimestamp, result.accountStatus) }
                                        when (language) {
                                            "Français" -> "Connexion réussie."
                                            "English" -> "Login successful."
                                            else -> "تم تسجيل الدخول بنجاح."
                                        }
                                    } else {
                                        when (language) {
                                            "Français" -> "Impossible de se connecter à ce serveur."
                                            "English" -> "Could not connect to this server."
                                            else -> "تعذر الاتصال بهذا الخادم."
                                        }
                                    }
                                    isLoading = false
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .semantics { contentDescription = "${fediText(language, "تسجيل الدخول إلى", "Connexion à", "Login to")} ${selectedServer?.displayName ?: fediText(language, "الخادم", "serveur", "server")}" },
                        colors = ButtonDefaults.buttonColors(containerColor = FediPurple),
                    ) {
                        Text(
                            when {
                                isLoading && language == "Français" -> "Vérification…"
                                isLoading && language == "English" -> "Checking…"
                                isLoading -> "جارٍ التحقق…"
                                language == "Français" -> "Se connecter"
                                language == "English" -> "Sign in"
                                else -> "دخول"
                            },
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                        )
                    }

                    if (status.isNotBlank()) {
                        Text(
                            text = status,
                            color = FediMuted,
                            modifier = Modifier.semantics { contentDescription = status },
                        )
                    }
                    Text(
                        text = selectedServer?.displayName ?: "",
                        color = FediMuted,
                        fontSize = 12.sp,
                        modifier = Modifier.semantics { contentDescription = "${fediText(language, "الخادم المحدد", "Serveur sélectionné", "Selected server")}: ${selectedServer?.displayName ?: fediText(language, "الخادم", "serveur", "server")}" },
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LanguageMenu(current: String, open: Boolean, onOpenChange: (Boolean) -> Unit, onSelect: (String) -> Unit) {
    ExposedDropdownMenuBox(expanded = open, onExpandedChange = onOpenChange) {
        OutlinedTextField(
            value = current,
            onValueChange = {},
            readOnly = true,
            label = { Text(fediText(current, "اللغة", "Langue", "Language")) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = open) },
            modifier = Modifier.menuAnchor().width(155.dp).semantics { contentDescription = "${fediText(current, "اللغة", "Langue", "Language")}: $current" },
        )
        DropdownMenu(expanded = open, onDismissRequest = { onOpenChange(false) }) {
            listOf("العربية", "Français", "English").forEach { item ->
                DropdownMenuItem(text = { Text(item) }, onClick = { onSelect(item); onOpenChange(false) })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ServerMenu(
    selected: String,
    open: Boolean,
    onOpenChange: (Boolean) -> Unit,
    servers: List<FediServer>,
    onSelect: (FediServer) -> Unit,
    label: String,
) {
    ExposedDropdownMenuBox(expanded = open, onExpandedChange = onOpenChange) {
        OutlinedTextField(
            value = selected,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = open) },
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
                .semantics { contentDescription = "$label: $selected" },
        )
        DropdownMenu(expanded = open, onDismissRequest = { onOpenChange(false) }) {
            servers.forEach { server ->
                DropdownMenuItem(
                    text = { Text(server.displayName) },
                    onClick = { onSelect(server); onOpenChange(false) },
                )
            }
        }
    }
}


@Composable
private fun CompositionLocalProviderWithDirection(direction: LayoutDirection, content: @Composable () -> Unit) {
    androidx.compose.runtime.CompositionLocalProvider(LocalLayoutDirection provides direction, content = content)
}
