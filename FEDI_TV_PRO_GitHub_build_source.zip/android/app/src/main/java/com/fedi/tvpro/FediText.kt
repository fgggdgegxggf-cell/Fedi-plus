package com.fedi.tvpro

/** Centralized UI copy for the three supported languages. */
internal fun fediText(language: String, arabic: String, french: String, english: String): String = when (language) {
    "Français" -> french
    "English" -> english
    else -> arabic
}

/** Direction follows the selected language; Arabic is the RTL language. */
internal fun isFediArabic(language: String): Boolean = language == "العربية"
