# خيارات بناء FEDI TV PRO من هاتف Android

## AndroidIDE

توضح الوثائق الرسمية أن AndroidIDE يستطيع فتح مشروع Gradle موجود أو استنساخ مستودع، ثم يبدأ بمزامنة Gradle وتنزيل التبعيات. بعد نجاح المزامنة، ينفذ زر Quick run مهمة `assembleDebug` ويتيح تثبيت APK الناتج. تذكر الوثائق أن أول بناء قد يستغرق 10 إلى 15 دقيقة حسب الاتصال.

المصدر: https://docs.androidide.com/tutorials/build-first-project.html
العنوان: Build your first project with AndroidIDE

## حالة المشروع

مستودع AndroidIDE على GitHub يذكر دعم Gradle وJDK 11 وJDK 17 ومدير SDK، لكنه يذكر أيضًا أن المشروع لم يعد محافظًا عليه. لذلك يجب تنزيله فقط من مصدر موثوق، وقد لا يعمل بسلاسة على كل هاتف حديث.

المصدر: https://github.com/AndroidIDEOfficial/AndroidIDE
العنوان: AndroidIDEOfficial/AndroidIDE

## الاستنتاج العملي

بالنسبة لملف FEDI TV PRO، الطريق الهاتفي الأقصر هو استخدام بيئة AndroidIDE أو تطبيق Android IDE موثوق يدعم مشاريع Gradle، ثم فتح مجلد `android` داخل الحزمة وتشغيل `assembleDebug`. لا يمكن لـ MT Manager وحده بناء Kotlin/Gradle من المصدر؛ دوره يبدأ بعد توفر APK لتثبيته أو توقيعه أو تعديله.

## Appcircle كخيار سحابي

تذكر صفحة Android CI/CD في Appcircle دعم مشاريع Android المبنية بـ Kotlin وJava وFlutter. وتعرض صفحة التسعير خطة Starter مجانية تتضمن بناءً متزامنًا واحدًا، مدة قصوى 30 دقيقة للبناء، و20 بناءً شهريًا. الخدمة مناسبة للبناء السحابي، لكنها تحتاج حسابًا وربطًا بمصدر المشروع أو طريقة رفع تدعمها المنصة؛ ليست تحويلًا فوريًا مجهولًا لملف ZIP بلمسة واحدة.

المصدر: https://appcircle.io/platforms/android-ci-cd
المصدر: https://appcircle.io/pricing
