# FEDI TV PRO

هذا المستودع مخصص فقط لمصدر تطبيق **FEDI TV PRO Android**. يوجد المصدر القابل للبناء داخل مجلد [`android/`](android/)، ويشمل تطبيقًا Native مبنيًا بـ Kotlin وJetpack Compose، مع دعم الهاتف وAndroid TV وAndroid Box.

يدعم التطبيق Xtream Codes، وعرض Live وMovies وSeries، وتشغيل Media3/ExoPlayer، واللغات العربية والفرنسية والإنجليزية، والتنقل بالريموت، وTalkBack، وواجهة Purple/White. تُقرأ إعدادات الخوادم من `android/app/src/main/assets/servers.json` ولا تُعرض عناوينها في شاشة الدخول.

## التحقق والبناء

يمكن تشغيل التحقق الثابت من جذر المشروع بالأمر التالي:

```bash
node android/validate_fedi_android.mjs
```

للبناء الفعلي، افتح مجلد `android` في Android Studio مع Android SDK وGradle، ثم نفّذ:

```bash
./gradlew :app:assembleDebug
```

بيئة sandbox الحالية لا تحتوي Android SDK أو Gradle Wrapper مكتملًا، لذلك لم يُنتج APK فعلي داخلها. يجب اختبار التطبيق ببيانات بث مصرح بها وعلى هاتف وAndroid TV/Box قبل إصدار Release موقّع.

## ملاحظة الاستخدام

يجب استخدام التطبيق فقط مع مصادر بث يملك المستخدم حقوق استخدامها. لا تُضمّن بيانات اعتماد العملاء أو رموز التفعيل الحقيقية داخل APK. التحقق الإنتاجي من التفعيل وربط الأجهزة يحتاج خادم إدارة يملكه المستخدم.

## بناء APK من الهاتف عبر GitHub

يحتوي المستودع على Workflow جاهز في [`.github/workflows/build-apk.yml`](.github/workflows/build-apk.yml). ارفع محتويات هذه الحزمة إلى مستودع GitHub خاص أو عام، مع الحفاظ على مجلد `android/` ومجلد `.github/`. من تبويب **Actions** اختر **Build FEDI TV PRO APK** ثم **Run workflow**. بعد انتهاء العملية افتح التشغيل الناجح، وانزل إلى **Artifacts**، ثم نزّل `fedi-tv-pro-debug-apk.zip` واستخرج منه ملف APK وثبّته على الهاتف.

إذا كان المصدر داخل مستودعك في جذر المشروع بدل مجلد `android/`، فالـ Workflow يتعرف تلقائيًا على الحالتين. لا تضع كلمات مرور أو رموز تفعيل حقيقية في المستودع؛ استخدم مستودعًا خاصًا عند الحاجة.
